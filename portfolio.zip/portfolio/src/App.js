import './App.css';
import Contact from './components/Contact/Contact';
import Footer from './components/Footer/Footer';
import Header from './components/Header/Header';
import Newsletter from './components/NewLetter/NewsLetter';
import Projects from './components/Projects/Projects';
import Resume from './components/Resume/Resume';
import Services from './components/Services/Services';
import WorkProcess from './components/WorkProcess/WorkProcess';

function App() {
  return (
    <div className="App">
    <Header />
    <Services />
    <WorkProcess />
    <Projects />
    <Resume />
    {/* <Newsletter /> */}
    <Contact />
    <Footer />
  </div>
);
}

export default App;
