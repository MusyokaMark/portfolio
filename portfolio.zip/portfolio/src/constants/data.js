import images from "./images";

const services = [
    {
        // image: `${images.services_img_1}`,
        title: "Web Design",
        paragraph: "Crafting visually appealing and user-friendly websites tailored to your business needs. We create engaging interfaces that captivate your audience and deliver a seamless browsing experience."
    },
    
    {
        // image: `${images.services_img_3}`,
        title: "UX Design",
        paragraph: "Enhancing user satisfaction by focusing on intuitive and efficient user experiences. We conduct thorough research, analyze user behavior, and design interfaces that optimize usability and drive conversions."
    },
   
    {
        // image: `${images.services_img_6}`,
        title: "Graphics",
        paragraph: "Transforming ideas into visually stunning graphics that resonate with your brand identity. Our graphic design services include logo design, branding materials, illustrations, and other captivating visuals."
    },
];

const works = [
    {
        image: `${images.work_img_1}`
    },
    {
        image: `${images.work_img_2}`
    },
    {
        image: `${images.work_img_3}`
    },
    {
        image: `${images.work_img_4}`
    },
    {
        image: `${images.work_img_5}`
    },
    {
        image: `${images.work_img_6}`
    },
];

const work_process = [
    {
        title: "Sketch",
        paragraph: "Explore design concepts"
    },
    {
        title: "Design",
        paragraph: "Create visually stunning interfaces"
    },
    {
        title: "Develop",
        paragraph: "Transform designs into functional websites"
    },
    {
        title: "End-Product",
        paragraph: "Deliver high-quality websites"
    },
];

const about_stats = [
    {
        image: `${images.stat_img_1}`,
        value: "1575",
        title: "Clients"
    },
    {
        image: `${images.stat_img_2}`,
        value: "2416",
        title: "Projects"
    },
    {
        image: `${images.stat_img_3}`,
        value: "4287",
        title: "Working Hours"
    },
    {
        image: `${images.stat_img_4}`,
        value: "287",
        title: "Awards"
    },
];

const testimonials = [
    {
        name: "Lelia Merritt",
        post: "Graphic Designer",
        paragraph: "Aliquam et odio arcu. Vestibulum pharetra tincidunt odio, sed pulvinar magna tempus quis. Mauris risus odio, semper sit amet tortor a, tristique consectetur urna."
    },
    {
        name: "John Huston",
        post: "Web Developer",
        paragraph: "Aliquam et odio arcu. Vestibulum pharetra tincidunt odio, sed pulvinar magna tempus quis. Mauris risus odio, semper sit amet tortor a, tristique consectetur urna."
    },
    {
        name: "Jeniffer Green",
        post: "Marketing Manager",
        paragraph: "Aliquam et odio arcu. Vestibulum pharetra tincidunt odio, sed pulvinar magna tempus quis. Mauris risus odio, semper sit amet tortor a, tristique consectetur urna."
    },
]

const logos = [
    {
        image: `${images.logo_img_1}`
    },
    {
        image: `${images.logo_img_2}`
    },
    {
        image: `${images.logo_img_3}`
    },
    {
        image: `${images.logo_img_4}`
    },
    {
        image: `${images.test_img_5}`
    },
    {
        image: `${images.test_img_6}`
    },
];

export {services, works, work_process, about_stats, testimonials, logos};