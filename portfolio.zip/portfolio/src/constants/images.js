// import work_img_1 from "../assets/images/work_img_1.jpeg";
// import work_img_2 from "../assets/images/work_img_2.png";
import work_img_1 from "../assets/images/work_img_1.png";
import work_img_2 from "../assets/images/work_img_2.png";
import work_img_3 from "../assets/images/work_img_3.png";
// import work_img_6 from "../assets/images/work_img_6.jpeg";
// import About_Alex from "../assets/images/About_Alex.jpg";
// import subscribe_background from "../assets/images/subscribe_background.jpeg";

const images = {
     work_img_1, work_img_2, work_img_3
}
export default images;