const ResumeApi = [
    {
        id: 1,
        category: "education",
        year: "Chuka University (2019 - 2023)",
        title: "Bachelor's Degree in Applied Computer Science",
        desc: "Studied at Chuka University from 2019 to 2023 and completed a Bachelor's Degree in Applied Computer Science. The program provided comprehensive knowledge and practical skills in computer science, including programming, data structures, algorithms, software development, database management, and computer networks. Participated in various projects and coursework, gaining hands-on experience in developing applications, analyzing complex problems, and implementing effective solutions",
        rate: "4.30/5",
    },
    
    {
        id: 2,
        category: "experience",
        year: "Machakos County Headquarters (2022 - 2022) ",
        title: "IT Support Intern",
      desc: "Worked at Machakos County Headquarters as an IT Support professional from 2019 to present. Provided technical assistance and troubleshooting for computer systems, software applications, and network infrastructure. Collaborated with colleagues to ensure smooth operations and efficient resolution of IT-related issues. Implemented security measures to protect systems and data from potential threats",
      rate: "4.95/5 ",
    },
    {
      id: 3,
      category: "experience",
      year: "Freelancing (2019 - Present)",
      title: "Computer Science Related",
      desc: "Worked as a freelance computer science professional since 2019. Developed customized software solutions, performed system analysis, and provided technical support. Proficient in programming languages, databases, and software development. Successfully managed multiple projects, delivering high-quality results within deadlines. Kept up-to-date with industry trends and upgraded skills. Built a strong reputation for reliability and exceptional client outcomes",
      rate: "5.00/5 ",
    },
  ]
  
  export default ResumeApi